# Census reproduction package

Recomputes the census H1, H2 and H4 analyses, and the supplementary without-overlap/without-abstract sensitivity, from per-paper numeric rows. The parser check (H3) is included only as frozen output (`data/parse_results_frozen.json`); rerunning it needs the public PDFs, the extracted text and spaCy, which are not included.

- `PROTOCOL.md`: the census protocol, frozen before any text was extracted, with its deviation log.
- `code/acl_run.py` and `scripts/review_round3/conference/conf_run.py`: the unchanged analysis code used by `reproduce.py`.
- `code/parse_check.py`, `code/figures.py`: the parser check and figure code, **for reference only**. They do not run as packaged: the parser check needs the PDFs, text and spaCy, and the figure code expects the original repository layout.
- `data/paper_rows.json`: numeric per-paper features for all 21,368 papers in the frame (Anthology ids, venue, year, track, status and rates; no text). 21,306 have status `admitted` and are analysed; 62 fell below the 1,500-body-word rule.
- `data/authors_anon.json`: opaque pseudonymous author ids (no names; public paper ids still allow byline linkage, so this is not a privacy guarantee), sufficient for the within-author panel.
- `data/overlap.json`: papers shared with the earlier discovery sample.
- `data/abstractless_ids.json`: the 460 papers without a usable abstract (rule, IDs, text hashes; recovered with the identical rule, see the protocol deviation log).
- `data/receipts.json`: SHA-256 of every retrieved PDF; the PDFs are public on the ACL Anthology.
- `data/results_frozen.json`, `data/parse_results_frozen.json`, `data/supplementary_frozen.json`: the frozen outputs reported in the paper.

## Running the check

Tested with Python 3.12.12 and NumPy 2.5.4 (NumPy 2.5.4 requires Python 3.12 or newer). Other versions are untested.

    python3.12 -m venv venv
    venv/bin/pip install numpy==2.5.4
    venv/bin/python reproduce.py

`reproduce.py` recomputes H1, H2 and H4 and the supplementary sensitivity and compares them with the frozen results. Numeric values, including interval endpoints and counts, must agree within relative 1e-9 / absolute 1e-12; booleans and strings must match exactly; missing keys or changed list lengths count as mismatches. `mismatches: 0` with exit code 0 means every compared value agreed under that rule. It reruns the same code with the same seeds, so it shows the reported numbers follow from these rows and this code; it is not an independent reimplementation. Same code and seeds do not guarantee bit-identical floating-point output on every platform.

Full-text extraction needs the public PDFs and is not required to check the statistics.
