#!/usr/bin/env python3
"""Round 4 ACL Anthology census: execute docs/review-round4/ACL_PROTOCOL.md.

Phases are resumable and refuse to run out of order. From the repository root:
  python3 -I scripts/review_round4/acl/acl_run.py fetch     # one <=SEGMENT_MIN-minute segment; rerun to resume
  python3 -I scripts/review_round4/acl/acl_run.py receipts  # receipts.json + fetch log copy (commit before extract)
  python3 -I scripts/review_round4/acl/acl_run.py extract   # unchanged extractor/features -> paper_rows.json (commit)
  python3 -I scripts/review_round4/acl/acl_run.py overlap   # abstracts vs original corpus (commit before analyze)
  python3 -I scripts/review_round4/acl/acl_run.py analyze   # H1, H2, H4 and exploratory scan -> results.json
  python3 -I scripts/review_round4/acl/acl_run.py status
H3 (parser check) is scripts/review_round4/acl/parse_check.py, run in the spaCy venv.

PDFs and extracted text stay in RAW (outside git). Committed files hold ids, URLs, hashes,
statuses and per-paper numeric endpoints only.
"""
import hashlib, importlib.util, json, os, re, subprocess, sys, time
from collections import Counter, defaultdict

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", ".."))
OUT = os.path.join(ROOT, "results", "review_round4", "acl")
CATALOG = os.path.join(OUT, "catalog.json")
RAW = os.environ.get("ACL_RAW", os.path.expanduser("~/agent-papers-data/before-after-ai/acl_census"))
FETCH_LOG = os.path.join(RAW, "fetch_log.jsonl")
LOG_COPY = os.path.join(OUT, "fetch_log.jsonl")
RECEIPTS = os.path.join(OUT, "receipts.json")
ROWS = os.path.join(OUT, "paper_rows.json")
OVERLAP = os.path.join(OUT, "overlap.json")
AUTHORS = os.path.join(OUT, "authors.json")
RESULTS = os.path.join(OUT, "results.json")
OLD_TEXT = os.path.expanduser("~/agent-papers-data/before-after-ai/v3-20261019/text")
ENDPOINTS = ("ing_func_1k", "ing_interp_core_1k", "addnot_1k")
PRE, POST = tuple(range(2016, 2023)), (2024, 2025)
NAACL_PRE = (2016, 2018, 2019, 2021, 2022)
SEED_H1, SEED_H2, SEED_H4, DRAWS = 20261021, 20261022, 20261023, 5000
UA = "before-after-ai-research/0.4 (ACL Anthology census; polite sequential fetch)"
SEGMENT_MIN = float(os.environ.get("SEGMENT_MIN", "85"))
PAUSE = 0.6
TRIES = 3


def sha(b):
    return hashlib.sha256(b).hexdigest()


def committed(path):
    rel = os.path.relpath(path, ROOT)
    r = subprocess.run(["git", "-C", ROOT, "status", "--porcelain", "--", rel], capture_output=True, text=True)
    t = subprocess.run(["git", "-C", ROOT, "ls-files", "--error-unmatch", rel], capture_output=True)
    return t.returncode == 0 and not r.stdout.strip()


def catalog():
    return json.load(open(CATALOG))


def pdf_path(i):
    return os.path.join(RAW, "pdfs", i + ".pdf")


def valid_pdf(p):
    if not os.path.exists(p):
        return False
    with open(p, "rb") as f:
        head = f.read(4)
        f.seek(max(0, os.path.getsize(p) - 2048))
        tail = f.read()
    return head == b"%PDF" and b"%%EOF" in tail


def fetch():
    rows = catalog()["rows"]
    os.makedirs(os.path.join(RAW, "pdfs"), exist_ok=True)
    tried = Counter(json.loads(l)["id"] for l in open(FETCH_LOG)) if os.path.exists(FETCH_LOG) else Counter()
    deadline, done = time.time() + SEGMENT_MIN * 60, 0
    for r in rows:
        i, url, dst = r["id"], r["url"], pdf_path(r["id"])
        if os.path.exists(dst) or tried[i] >= TRIES:
            continue
        if time.time() > deadline:
            print("segment time limit reached; rerun to resume", flush=True)
            break
        for attempt in range(tried[i] + 1, TRIES + 1):  # same pinned URL only
            p = subprocess.run(["curl", "-sL", "-A", UA, "--max-time", "300", "-w", "%{http_code} %{url_effective}",
                                "-o", dst + ".part", url], capture_output=True, text=True)
            http, _, final_url = p.stdout.partition(" ")
            if http in ("429", "503"):
                if os.path.exists(dst + ".part"):
                    os.remove(dst + ".part")
                sys.exit(f"HTTP {http} at {i}; halting without logging an attempt. Rerun later.")
            ok = valid_pdf(dst + ".part")
            with open(FETCH_LOG, "a") as f:
                f.write(json.dumps({"id": i, "attempt": attempt, "url": url, "http": http, "final_url": final_url,
                                    "bytes": os.path.getsize(dst + ".part") if os.path.exists(dst + ".part") else 0,
                                    "valid_pdf": ok, "utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())}) + "\n")
            time.sleep(PAUSE)
            if ok:
                os.replace(dst + ".part", dst)
                break
            time.sleep(PAUSE * 5 * attempt)
        if os.path.exists(dst + ".part"):
            os.remove(dst + ".part")
        done += 1
    status()


# ---------------------------------------------------------------- receipts / extract / overlap
def receipts():
    """Refuses a partial corpus unless RECEIPTS_DEVIATION holds a dated deviation note."""
    import shutil
    assert committed(CATALOG)
    rows = catalog()["rows"]
    missing = [r["id"] for r in rows if not valid_pdf(pdf_path(r["id"]))]
    deviation = os.environ.get("RECEIPTS_DEVIATION", "").strip()
    if missing and not deviation:
        sys.exit(f"{len(missing)} PDFs missing (first: {missing[:5]}); rerun fetch or set RECEIPTS_DEVIATION")
    shutil.copyfile(FETCH_LOG, LOG_COPY)
    items = []
    for r in rows:
        p = pdf_path(r["id"]); it = {"id": r["id"], "retrieved": valid_pdf(p)}
        if it["retrieved"]:
            b = open(p, "rb").read(); it["pdf_sha256"], it["pdf_bytes"] = sha(b), len(b)
        items.append(it)
    json.dump({"phase": "receipts_frozen_before_extraction", "catalog_sha256": sha(open(CATALOG, "rb").read()),
               "fetch_log_sha256": sha(open(LOG_COPY, "rb").read()), "missing": missing,
               "deviation": deviation or None, "items": items}, open(RECEIPTS, "w"), indent=0, sort_keys=True)
    print(Counter(i["retrieved"] for i in items))


def text_path(i):
    return os.path.join(RAW, "text", i + ".json")


def _extract(args):
    sys.path.insert(0, os.path.join(ROOT, "scripts", "review_round2", "reproduction"))
    import repro  # binds the hashed extractor snapshot, as in the main study and rounds 2-3
    i, pdf, dst = args
    if os.path.exists(dst):
        os.remove(dst)
    try:
        ok = repro.EXTRACT.one(("acl", pdf, dst))
    except Exception as e:
        return i, "extraction_error:" + type(e).__name__, None
    if not ok:
        return i, "extraction_failed", None
    f = repro.FEATURES.paper_features(json.load(open(dst)))
    if f is None:
        return i, "excluded_under_1500_words", None
    row = {k: (round(v, 6) if isinstance(v, float) else v) for k, v in f.items()
           if isinstance(v, (int, float)) and not isinstance(v, bool) or k == "llm_topic"}
    row["addnot_1k"] = round(f["op_additionally_1k"] + f["op_notably_1k"], 6)
    return i, "admitted", row


def extract():
    from multiprocessing import Pool
    assert committed(RECEIPTS) and committed(LOG_COPY) and committed(AUTHORS), "commit receipts, fetch log, authors"
    rec = json.load(open(RECEIPTS))
    assert rec["catalog_sha256"] == sha(open(CATALOG, "rb").read())
    assert rec["fetch_log_sha256"] == sha(open(LOG_COPY, "rb").read())
    assert not rec["missing"] or rec["deviation"]
    meta = {r["id"]: r for r in catalog()["rows"]}
    assert [i["id"] for i in rec["items"]] == sorted(meta)
    jobs, status = [], {}
    for it in rec["items"]:
        p = pdf_path(it["id"])
        if not it["retrieved"]:
            status[it["id"]] = {"status": "not_retrieved"}
        elif sha(open(p, "rb").read()) != it["pdf_sha256"]:
            status[it["id"]] = {"status": "hash_mismatch_with_receipts"}
        else:
            jobs.append((it["id"], p, text_path(it["id"])))
    os.makedirs(os.path.join(RAW, "text"), exist_ok=True)
    with Pool(8) as pool:
        for i, st, f in pool.imap_unordered(_extract, jobs, chunksize=16):
            status[i] = {"status": st, **(f or {})}
    out = [{"id": i, "venue": meta[i]["venue"], "year": meta[i]["year"], "track": meta[i]["track"], **status[i]}
           for i in sorted(meta)]
    json.dump({"receipts_sha256": sha(open(RECEIPTS, "rb").read()), "rows": out}, open(ROWS, "w"), indent=0, sort_keys=True)
    print(Counter((r["venue"], r["status"]) for r in out))


def _shingles(text, n=5):
    w = re.findall(r"[a-z]+", text.lower())
    return {" ".join(w[j:j + n]) for j in range(max(0, len(w) - n + 1))}


def overlap():
    """Census papers whose extracted abstract has word 5-gram containment >= 0.5 in one original-corpus abstract."""
    assert committed(ROWS)
    index = defaultdict(set)
    for root, _, files in os.walk(OLD_TEXT):
        for fn in files:
            r = json.load(open(os.path.join(root, fn)))
            for s in _shingles(r.get("abstract") or ""):
                index[s].add(r["corpus"] + ":" + r["id"])
    matches, missing = {}, 0
    for r in json.load(open(ROWS))["rows"]:
        if r["status"] != "admitted":
            continue
        sh = _shingles(json.load(open(text_path(r["id"]))).get("abstract") or "")
        if len(sh) < 10:
            missing += 1; continue
        best = Counter(k for s in sh for k in index.get(s, ())).most_common(1)
        if best and best[0][1] / len(sh) >= 0.5:
            matches[r["id"]] = best[0][0]
    json.dump({"rule": "extracted abstract word 5-gram containment >= 0.5 in one original-corpus abstract",
               "n_without_usable_abstract": missing, "overlapping": matches}, open(OVERLAP, "w"), indent=1, sort_keys=True)
    print(len(matches), "overlapping;", missing, "without usable abstract")


# ---------------------------------------------------------------- analysis (numeric rows only)
def _lane_a():
    """The round-3 lane A functions, imported unchanged."""
    spec = importlib.util.spec_from_file_location("conf_run", os.path.join(ROOT, "scripts", "review_round3", "conference", "conf_run.py"))
    m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
    assert tuple(m.ENDPOINTS) == ENDPOINTS
    return m


def cells(rows, keep=lambda r: True):
    import numpy as np
    by = defaultdict(list)
    for r in rows:
        if r["status"] == "admitted" and keep(r):
            by[(r["venue"], r["year"])].append([r[e] for e in ENDPOINTS])
    return {k: np.array(v, dtype=float) for k, v in by.items()}


def h1_block(A, by, venues, pre, post, seed=SEED_H1, draws=DRAWS):
    p = A.excess_point(by, venues, pre, post)
    d, diag = A.forecast_interval(by, venues, pre, post, draws=draws, seed=seed)
    s = A.summarize(p, d); s["venues"] = {venues[i]: v for i, v in s["venues"].items()}
    s["verdict"] = A.verdict(s["equal_venue"])
    return s, diag


def h1(A, rows, overlap_ids):
    import numpy as np
    V = ("acl", "emnlp")
    by = cells(rows)
    prim, diag = h1_block(A, by, V, PRE, POST)
    rep = {"primary": prim, "residual_diagnostics": diag}
    cond = A.summarize(A.excess_point(by, V, PRE, POST), A.conditional_interval(by, V, PRE, POST, seed=SEED_H1))
    cond["venues"] = {V[i]: v for i, v in cond["venues"].items()}
    rep["supplemental_conditional_paper_bootstrap"] = cond
    rep["placebo_fit_2016_2019_forecast_2020_2021"], _ = h1_block(A, by, V, tuple(range(2016, 2020)), (2020, 2021))
    rep["placebo_fit_2016_2020_forecast_2021_2022"], _ = h1_block(A, by, V, tuple(range(2016, 2021)), (2021, 2022))
    def raw(b):
        return (A.annual(b, V, POST).mean(axis=0) - A.annual(b, V, (2019, 2020)).mean(axis=0)).reshape(len(V), -1)
    rng = np.random.default_rng(SEED_H1)
    rd = np.array([raw({k: b[rng.integers(len(b), size=len(b))] for k, b in by.items()}) for _ in range(2000)])
    r = A.summarize(raw(by), rd); r["venues"] = {V[i]: v for i, v in r["venues"].items()}
    rep["secondary_raw_2024_25_minus_2019_20"] = r
    sens = {"llm_topic_0": lambda x: x["llm_topic"] == 0, "long_or_main_track": lambda x: x["track"] != "short",
            "without_original_corpus_overlap": lambda x: x["id"] not in overlap_ids}
    for name, f in sens.items():
        b = cells(rows, f)
        rep["sensitivity_" + name], _ = h1_block(A, b, V, PRE, POST)
        rep["sensitivity_" + name]["cell_n"] = {f"{v}{y}": int(len(b.get((v, y), []))) for v in V for y in range(2016, 2027)}
    rep["sensitivity_pre_line_2016_2021"], _ = h1_block(A, by, V, tuple(range(2016, 2022)), POST)
    rep["naacl_separate"], _ = h1_block(A, by, ("naacl",), NAACL_PRE, POST)
    rep["cell_n"] = {f"{v}{y}": int(len(a)) for (v, y), a in sorted(by.items())}
    rep["cell_means"] = {f"{v}{y}": dict(zip(ENDPOINTS, map(float, a.mean(axis=0)))) for (v, y), a in sorted(by.items())}
    return rep


def h2(rows, byline, orcid):
    import numpy as np
    real, plac = ((2020, 2021, 2022), (2024, 2025, 2026)), ((2016, 2017, 2018), (2020, 2021, 2022))
    first = {i: ks[0] for i, ks in byline.items() if ks}
    last = {i: ks[-1] for i, ks in byline.items() if len(ks) >= 2}
    nfirst = Counter(first.values())

    def deltas(owner, windows, keep):
        a, b = windows
        acc = defaultdict(lambda: ([], []))
        for r in rows:
            if r["status"] != "admitted" or r["id"] not in owner or not keep(r, owner[r["id"]]):
                continue
            if r["year"] in a or r["year"] in b:
                acc[owner[r["id"]]][r["year"] in b].append([r[e] for e in ENDPOINTS])
        return {k: np.mean(post, axis=0) - np.mean(pre, axis=0) for k, (pre, post) in acc.items() if pre and post}

    def ci(x, q=(.025, .975)):
        return [float(v) for v in np.quantile(x, q)]

    def panel(owner, keep, with_placebo=False):
        Dr = deltas(owner, real, keep)
        keys = sorted(Dr)
        M = np.array([Dr[k] for k in keys])
        rng = np.random.default_rng(SEED_H2)
        sims = np.array([M[rng.integers(len(M), size=len(M))].mean(axis=0) for _ in range(DRAWS)])
        out = {"n_authors": len(keys), "within_author_change": {
            e: {"est": float(M[:, j].mean()), "ci95": ci(sims[:, j])} for j, e in enumerate(ENDPOINTS)}}
        w = out["within_author_change"]
        out["verdict"] = ("full_three_endpoint_replication" if all(w[e]["ci95"][0] > 0 for e in ENDPOINTS) else
                          ("contrary:" + ",".join(e for e in ENDPOINTS if w[e]["ci95"][1] < 0)
                           if any(w[e]["ci95"][1] < 0 for e in ENDPOINTS) else "mixed_or_inconclusive"))
        if with_placebo:
            Dp = deltas(owner, plac, keep)
            union = sorted(set(Dr) | set(Dp))
            R = np.array([Dr.get(k, np.full(len(ENDPOINTS), np.nan)) for k in union])
            P = np.array([Dp.get(k, np.full(len(ENDPOINTS), np.nan)) for k in union])
            rng = np.random.default_rng(SEED_H2 + 1)
            ds, ps = [], []
            for _ in range(DRAWS):
                idx = rng.integers(len(union), size=len(union))
                r_, p_ = np.nanmean(R[idx], axis=0), np.nanmean(P[idx], axis=0)
                ds.append(r_ - p_); ps.append(p_)
            ds, ps = np.array(ds), np.array(ps)
            pm = np.nanmean(P, axis=0)
            out["placebo_2016_18_to_2020_22"] = {"n_authors": len(Dp), "n_in_both_panels": len(set(Dr) & set(Dp)),
                                                 "change": {e: {"est": float(pm[j]), "ci95": ci(ps[:, j])} for j, e in enumerate(ENDPOINTS)}}
            out["placebo_adjusted_did"] = {e: {"est": float(M[:, j].mean() - pm[j]), "ci95": ci(ds[:, j])}
                                           for j, e in enumerate(ENDPOINTS)}
        return out

    allk = lambda r, k: True
    rep = {"primary_first_author": panel(first, allk, with_placebo=True),
           "sensitivity_orcid_keys": panel(first, lambda r, k: k in orcid),
           "sensitivity_max_12_first_author_papers": panel(first, lambda r, k: nfirst[k] <= 12),
           "sensitivity_llm_topic_0": panel(first, lambda r, k: r["llm_topic"] == 0),
           "contrast_last_author": panel(last, allk)}
    # all-paper change between the same windows, paper-weighted, all three venues (descriptive)
    adm = [r for r in rows if r["status"] == "admitted"]
    a = np.array([[r[e] for e in ENDPOINTS] for r in adm if r["year"] in real[0]])
    b = np.array([[r[e] for e in ENDPOINTS] for r in adm if r["year"] in real[1]])
    rep["all_paper_change_same_windows"] = dict(zip(ENDPOINTS, map(float, b.mean(axis=0) - a.mean(axis=0))))
    return rep


def h4(rows):
    import numpy as np
    by = cells(rows, lambda r: r["venue"] == "acl")
    rng = np.random.default_rng(SEED_H4)
    a25, a26 = by[("acl", 2025)], by[("acl", 2026)]
    sims = np.array([a26[rng.integers(len(a26), size=len(a26))].mean(axis=0) - a25[rng.integers(len(a25), size=len(a25))].mean(axis=0)
                     for _ in range(DRAWS)])
    est = a26.mean(axis=0) - a25.mean(axis=0)
    pre = {f"{y}->{y + 1}": dict(zip(ENDPOINTS, map(float, by[("acl", y + 1)].mean(axis=0) - by[("acl", y)].mean(axis=0))))
           for y in range(2016, 2022)}
    out = {"acl2025_mean": dict(zip(ENDPOINTS, map(float, a25.mean(axis=0)))),
           "acl2026_mean": dict(zip(ENDPOINTS, map(float, a26.mean(axis=0)))),
           "n": {"acl2025": int(len(a25)), "acl2026": int(len(a26))},
           "diff_2026_minus_2025": {e: {"est": float(est[j]), "ci95": [float(x) for x in np.quantile(sims[:, j], [.025, .975])]}
                                    for j, e in enumerate(ENDPOINTS)},
           "pre_period_year_to_year_changes": pre}
    sd = np.sqrt((a25.var(axis=0, ddof=1) / len(a25)) + (a26.var(axis=0, ddof=1) / len(a26)))
    out["mde_80pct_power_one_sided_0025"] = dict(zip(ENDPOINTS, map(float, (1.959964 + 0.841621) * sd)))
    out["confirmed_openers_lower_in_2026"] = out["diff_2026_minus_2025"]["addnot_1k"]["ci95"][1] < 0
    return out


def exploratory(A, rows):
    """All numeric features: H1 point excess (ACL+EMNLP) and a BH-adjusted conditional paper-bootstrap p-value."""
    import numpy as np
    V = ("acl", "emnlp")
    adm = [r for r in rows if r["status"] == "admitted"]
    feats = sorted(k for k in adm[0] if isinstance(adm[0][k], (int, float)) and k not in ("year",)
                   and all(k in r for r in adm))
    out = {}
    rng = np.random.default_rng(SEED_H1)
    by = defaultdict(list)
    for r in adm:
        by[(r["venue"], r["year"])].append([r[k] for k in feats])
    by = {k: np.array(v, dtype=float) for k, v in by.items()}
    def point(b):
        Y = np.concatenate([np.array([b[(v, y)].mean(axis=0) for y in PRE]) for v in V], axis=1)
        X = np.column_stack([np.ones(len(PRE)), np.array(PRE, float) - 2016])
        coef, *_ = np.linalg.lstsq(X, Y, rcond=None)
        P = np.concatenate([np.array([b[(v, y)].mean(axis=0) for y in POST]) for v in V], axis=1)
        Xp = np.column_stack([np.ones(len(POST)), np.array(POST, float) - 2016])
        ex = (P - Xp @ coef).mean(axis=0).reshape(len(V), -1).mean(axis=0)
        sd = np.sqrt(np.mean([b[(v, y)].var(axis=0) for v in V for y in (2019, 2020)], axis=0))
        return ex, sd
    est, sd = point(by)
    sims = np.array([point({k: a[rng.integers(len(a), size=len(a))] for k, a in by.items()})[0] for _ in range(1000)])
    p = np.minimum(1, 2 * np.minimum((sims <= 0).mean(axis=0), (sims >= 0).mean(axis=0)) + 1 / 1000)
    order = np.argsort(p); m = len(p); q = np.empty(m); prev = 1.0
    for rank, idx in reversed(list(enumerate(order, 1))):
        prev = min(prev, p[idx] * m / rank); q[idx] = prev
    for j, k in enumerate(feats):
        out[k] = {"excess": float(est[j]), "excess_in_pre_paper_sd": float(est[j] / sd[j]) if sd[j] > 0 else None,
                  "p_conditional": float(p[j]), "q_bh": float(q[j])}
    return {"note": "exploratory; conditional on calendar years; not a replication test", "features": out}


def analyze():
    assert committed(ROWS) and committed(OVERLAP) and committed(AUTHORS)
    rows = json.load(open(ROWS))["rows"]
    au = json.load(open(AUTHORS))
    A = _lane_a()
    rep = {"rows_sha256": sha(open(ROWS, "rb").read()), "authors_sha256": sha(open(AUTHORS, "rb").read()),
           "status_counts": {f"{v}{y}": dict(Counter(r["status"] for r in rows if r["venue"] == v and r["year"] == y))
                             for v, y in sorted({(r["venue"], r["year"]) for r in rows})}}
    rep["H1"] = h1(A, rows, set(json.load(open(OVERLAP))["overlapping"]))
    rep["H2"] = h2(rows, au["byline"], set(au["orcid_keys"]))
    rep["H4"] = h4(rows)
    rep["exploratory"] = exploratory(A, rows)
    json.dump(rep, open(RESULTS, "w"), indent=1, sort_keys=True)
    print(json.dumps({"H1": rep["H1"]["primary"]["equal_venue"], "H1_verdict": rep["H1"]["primary"]["verdict"],
                      "H2": rep["H2"]["primary_first_author"]["within_author_change"], "H2_verdict": rep["H2"]["primary_first_author"]["verdict"],
                      "H4": rep["H4"]["diff_2026_minus_2025"]}, indent=1))


def status():
    rows = catalog()["rows"]
    have = sum(os.path.exists(pdf_path(r["id"])) for r in rows)
    print(f"{have} of {len(rows)} PDFs present", flush=True)


if __name__ == "__main__":
    {"fetch": fetch, "receipts": receipts, "extract": extract, "overlap": overlap, "analyze": analyze,
     "status": status}[sys.argv[1]]()
