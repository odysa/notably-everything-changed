#!/usr/bin/env python3
"""Round 4 H3: are the regex rider hits parse-confirmed at the same rate in both eras?

Runs in the spaCy venv (Python 3.12, spaCy 3.8, en_core_web_lg 3.8.0). From the repository root:
  <venv>/bin/python -I scripts/review_round4/acl/parse_check.py parse     # -> parse_rows.json (commit)
  <venv>/bin/python -I scripts/review_round4/acl/parse_check.py analyze   # -> parse_results.json

For each admitted census paper, the policy-filtered body is split into sentences exactly as in
features.paper_features, and every candidate counted by features.ing_riders (same pattern, same
position >= 25 rule, same word lists) is located. A candidate is parse-confirmed if the matched
token is tagged VBG, its dependency label is advcl/acl/xcomp/conj and its head precedes it;
strict = advcl only. Only sentences holding a candidate are parsed.
"""
import hashlib, importlib.util, json, os, re, sys
from collections import Counter
from multiprocessing import Pool

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", ".."))
OUT = os.path.join(ROOT, "results", "review_round4", "acl")
RAW = os.environ.get("ACL_RAW", os.path.expanduser("~/agent-papers-data/before-after-ai/acl_census"))
ROWS, PROWS, PRES = (os.path.join(OUT, f) for f in ("paper_rows.json", "parse_rows.json", "parse_results.json"))
PAT = re.compile(r",\s+(?:thereby |thus |further |ultimately |effectively )?([a-z]+ing)\b")
LENIENT, STRICT = {"advcl", "acl", "xcomp", "conj"}, {"advcl"}
MODEL = "en_core_web_lg"
SEED = 20261024

_nlp = _F = None


def _init():
    global _nlp, _F
    import spacy
    sys.path.insert(0, os.path.join(ROOT, "scripts", "review_round2", "reproduction"))
    import repro
    _F = repro.FEATURES
    _nlp = spacy.load(MODEL, disable=["ner", "lemmatizer"])


def _one(pid):
    rec = json.load(open(os.path.join(RAW, "text", pid + ".json")))
    paras = _F.drop_policy(rec)
    sents = [s for p in paras for s in _F.sentences(p)]
    cands = []  # (sentence index, char offset of the -ing word, class)
    for si, s in enumerate(sents):
        for m in PAT.finditer(s):
            v = m.group(1)
            if m.start() < 25:
                continue
            if v in _F.INTERP_CORE:
                cands.append((si, m.start(1), "core"))
            elif v in _F.FUNC and v not in _F.INTERP:  # same precedence as ing_riders
                cands.append((si, m.start(1), "func"))
    c = Counter()
    want = sorted({si for si, _, _ in cands})
    docs = dict(zip(want, _nlp.pipe([sents[i] for i in want], batch_size=64)))
    for si, off, cls in cands:
        tok = next((t for t in docs[si] if t.idx == off), None)
        c[cls + "_hits"] += 1
        if tok is None:
            c[cls + "_unaligned"] += 1
            continue
        ok = tok.tag_ == "VBG" and tok.head.i < tok.i
        c[cls + "_confirmed"] += ok and tok.dep_ in LENIENT
        c[cls + "_strict"] += ok and tok.dep_ in STRICT
    return pid, dict(c)


def parse():
    rows = [r for r in json.load(open(ROWS))["rows"] if r["status"] == "admitted"]
    import spacy
    out = {}
    with Pool(8, initializer=_init) as pool:
        for n, (pid, c) in enumerate(pool.imap_unordered(_one, [r["id"] for r in rows], chunksize=8)):
            out[pid] = c
            if n % 2000 == 0:
                print(n, flush=True)
    meta = {"model": MODEL, "model_version": spacy.load(MODEL).meta["version"], "spacy": spacy.__version__,
            "rows_sha256": hashlib.sha256(open(ROWS, "rb").read()).hexdigest(), "lenient": sorted(LENIENT),
            "strict": sorted(STRICT)}
    json.dump({"meta": meta, "papers": dict(sorted(out.items()))}, open(PROWS, "w"), indent=0, sort_keys=True)


def analyze():
    import numpy as np
    spec = importlib.util.spec_from_file_location("acl_run", os.path.join(os.path.dirname(__file__), "acl_run.py"))
    acl = importlib.util.module_from_spec(spec); spec.loader.exec_module(acl)
    A = acl._lane_a()
    rows = {r["id"]: r for r in json.load(open(ROWS))["rows"] if r["status"] == "admitted"}
    P = json.load(open(PROWS))["papers"]
    V = ("acl", "emnlp")
    rep = {"meta": json.load(open(PROWS))["meta"]}
    # (a) confirmed share of regex hits by era, pooled over hits, paper bootstrap for the era difference
    rng = np.random.default_rng(SEED)
    for cls in ("func", "core"):
        for kind in ("confirmed", "strict"):
            res = {}
            eras = {"2019_20": (2019, 2020), "2024_25": (2024, 2025)}
            arr = {k: np.array([[P[i].get(cls + "_hits", 0), P[i].get(cls + "_" + kind, 0)]
                                for i, r in rows.items() if r["year"] in ys and r["venue"] in V], float)
                   for k, ys in eras.items()}
            for k, a in arr.items():
                res[k] = {"hits": int(a[:, 0].sum()), "share": float(a[:, 1].sum() / a[:, 0].sum())}
            sims = []
            for _ in range(2000):
                s = {k: a[rng.integers(len(a), size=len(a))] for k, a in arr.items()}
                sims.append(s["2024_25"][:, 1].sum() / s["2024_25"][:, 0].sum() - s["2019_20"][:, 1].sum() / s["2019_20"][:, 0].sum())
            res["diff_post_minus_pre"] = {"est": res["2024_25"]["share"] - res["2019_20"]["share"],
                                          "ci95": [float(x) for x in np.quantile(sims, [.025, .975])],
                                          "ci90": [float(x) for x in np.quantile(sims, [.05, .95])]}
            res["unaligned"] = {k: int(sum(P[i].get(cls + "_unaligned", 0) for i, r in rows.items()
                                           if r["year"] in ys and r["venue"] in V)) for k, ys in eras.items()}
            rep[f"share_{cls}_{kind}"] = res
    # (b) H1 recomputed on parse-confirmed rates per 1,000 words (openers unchanged)
    for kind in ("confirmed", "strict"):
        by = {}
        for i, r in rows.items():
            k = 1000.0 / r["words"]
            by.setdefault((r["venue"], r["year"]), []).append(
                [P[i].get("func_" + kind, 0) * k, P[i].get("core_" + kind, 0) * k, r["addnot_1k"]])
        by = {k: np.array(v, float) for k, v in by.items()}
        s, _ = acl.h1_block(A, by, V, acl.PRE, acl.POST)
        s["equal_venue"].pop("addnot_1k"); s.pop("verdict")  # openers are unparsed: keep their original H1
        for v in s["venues"].values():
            v.pop("addnot_1k")
        rep[f"H1_on_parse_{kind}"] = s
    lo_ok = all(rep["H1_on_parse_confirmed"]["equal_venue"][e]["ci95"][0] > 0 for e in ("ing_func_1k", "ing_interp_core_1k"))
    small = all(-0.10 < x < 0.10 for c in ("func", "core") for x in rep[f"share_{c}_confirmed"]["diff_post_minus_pre"]["ci90"])
    rep["interpretation_rule_met"] = bool(lo_ok and small)
    json.dump(rep, open(PRES, "w"), indent=1, sort_keys=True)
    print(json.dumps({k: v for k, v in rep.items() if k.startswith("share")}, indent=1))
    print(json.dumps({k: rep[k]["equal_venue"] for k in rep if k.startswith("H1_")}, indent=1), rep["interpretation_rule_met"])


if __name__ == "__main__":
    {"parse": parse, "analyze": analyze}[sys.argv[1]]()
