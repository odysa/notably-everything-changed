#!/usr/bin/env python3
"""Round 4 figures from committed results only (results.json). Run in the round-4 venv:
  <venv>/bin/python -I scripts/review_round4/acl/figures.py
"""
import json, os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", ".."))
RES = json.load(open(os.path.join(ROOT, "results", "review_round4", "acl", "results.json")))
FIG = os.path.join(ROOT, "paper", "acl", "figs")
E = [("ing_func_1k", "Functional -ing clauses"), ("ing_interp_core_1k", "Interpretive -ing clauses"),
     ("addnot_1k", "Additionally / Notably openers")]
COL = {"acl": "#2b6cb0", "emnlp": "#c05621", "naacl": "#4a7c59"}
plt.rcParams.update({"font.size": 8, "axes.spines.top": False, "axes.spines.right": False,
                     "font.family": "serif"})


def series():
    H1 = RES["H1"]; cm = H1["cell_means"]
    fig, axes = plt.subplots(1, 3, figsize=(6.3, 2.0))
    for ax, (e, title) in zip(axes, E):
        ax.axvspan(2022.5, 2023.5, color="0.92", lw=0)
        for v in ("acl", "emnlp", "naacl"):
            ys = sorted(int(k[len(v):]) for k in cm if k.startswith(v) and k[len(v):].isdigit())
            ax.plot(ys, [cm[f"{v}{y}"][e] for y in ys], "o-", color=COL[v], ms=2.5, lw=1.1, label=v.upper())
            if v != "naacl":
                pre = [y for y in ys if y <= 2022]
                b, a = np.polyfit(pre, [cm[f"{v}{y}"][e] for y in pre], 1)
                xs = np.array([2016, 2025])
                ax.plot(xs, a + b * xs, "--", color=COL[v], lw=0.7, alpha=0.7)
        ax.set_title(title, fontsize=8)
        ax.set_xticks([2016, 2019, 2022, 2025])
    axes[0].set_ylabel("per 1,000 words")
    axes[0].legend(frameon=False, fontsize=7, loc="upper left")
    fig.tight_layout(pad=0.3)
    fig.savefig(os.path.join(FIG, "acl_series.pdf"))


def panel():
    """Changes as % of the all-paper change between 2020-22 and 2024-26, one group per endpoint."""
    H2 = RES["H2"]; p = H2["primary_first_author"]
    fig, ax = plt.subplots(figsize=(3.1, 1.55))
    labs = ["Functional", "Interpretive", "Openers"]
    for j, (e, _) in enumerate(E):
        base = H2["all_paper_change_same_windows"][e]
        same = p["within_author_change"][e]; pre = p["placebo_2016_18_to_2020_22"]["change"][e]
        for k, (m, ci, c, lab) in enumerate([(base, None, "0.65", "All papers, 2020-22 to 2024-26"),
                                             (same["est"], same["ci95"], "#2b6cb0", "Same 762 first authors"),
                                             (pre["est"], pre["ci95"], "#c05621", "554 repeat authors, 2016-18 to 2020-22")]):
            x = j + (k - 1) * 0.26
            ax.bar(x, 100 * m / base, width=0.24, color=c, label=lab if j == 0 else None)
            if ci:
                ax.plot([x, x], [100 * ci[0] / base, 100 * ci[1] / base], color="k", lw=0.7)
    ax.axhline(0, color="k", lw=0.5)
    ax.set_xticks(range(3)); ax.set_xticklabels(labs)
    ax.set_ylabel("% of all-paper change"); ax.set_ylim(-5, 165)
    ax.legend(frameon=False, fontsize=5.8, loc="upper left", ncol=1)
    fig.tight_layout(pad=0.3)
    fig.savefig(os.path.join(FIG, "acl_panel.pdf"))


def openers():
    """Share of each opener among the 17 counted sentence openers, ACL by year (exploratory)."""
    ex = json.load(open(os.path.join(ROOT, "results", "review_round4", "acl", "explore_openers.json")))["by_cell"]
    ys = list(range(2016, 2027))
    fig, ax = plt.subplots(figsize=(3.1, 1.6))
    for k, lab, c in [("op_additionally_1k", "Additionally", "#2b6cb0"), ("op_notably_1k", "Notably", "#c05621"),
                      ("op_crucially_1k", "Crucially", "#4a7c59"), ("op_thus_1k", "Thus", "0.55")]:
        ax.plot(ys, [100 * ex[f"acl{y}"][k] / ex[f"acl{y}"]["all_openers_1k"] for y in ys], "o-", ms=2.5, lw=1.1,
                color=c, label=lab)
    ax.set_ylabel("% of openers"); ax.set_xticks([2016, 2019, 2022, 2025])
    ax.legend(frameon=False, fontsize=6.5, ncol=2)
    fig.tight_layout(pad=0.3)
    fig.savefig(os.path.join(FIG, "acl_openers.pdf"))


if __name__ == "__main__":
    series(); panel(); openers()
