#!/usr/bin/env python3
"""Round 3 lane A: USENIX FAST, Security and ATC 2016-2025 full census
(docs/review-round3/design/CONFERENCE_PROTOCOL.md, frozen rules ec75863).

Every phase is resumable and refuses to run out of order. From the repository root:
  python3 -I scripts/review_round3/conference/conf_run.py manifest  # manifest.json from the census (commit it)
  python3 -I scripts/review_round3/conference/conf_run.py fetch     # PDFs into RAW; stops after SEGMENT_MIN
  python3 -I scripts/review_round3/conference/conf_run.py receipts  # receipts.json (commit before extraction)
  python3 -I scripts/review_round3/conference/conf_run.py extract   # text + per-paper endpoints (paper_status.json)
  python3 -I scripts/review_round3/conference/conf_run.py analyze   # results.json
  python3 -I scripts/review_round3/conference/conf_run.py status

PDFs and extracted text stay in RAW (outside git). Committed files hold ids, URLs, hashes, statuses and
per-paper numeric endpoints only.
"""
import hashlib, json, os, subprocess, sys, time
from collections import Counter, defaultdict

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", ".."))
CENSUS = os.path.join(ROOT, "results", "review_round3", "catalog", "usenix_census.jsonl")
CENSUS_SHA256 = "f4dcabc48431ebfef2abf5987c0da83bba072c63dd7e5810e0bbbf649da42427"  # commit f08e628
OUT = os.path.join(ROOT, "results", "review_round3", "conference")
RAW = os.path.expanduser("~/agent-papers-data/before-after-ai/round3-usenix")
MANIFEST, RECEIPTS = os.path.join(OUT, "manifest.json"), os.path.join(OUT, "receipts.json")
STATUS = os.path.join(OUT, "paper_status.json")
FETCH_LOG = os.path.join(RAW, "fetch_log.jsonl")
FETCH_LOG_OUT = os.path.join(OUT, "fetch_log.jsonl")
UA = "Mozilla/5.0 (research corpus study)"
VENUES = ("fast", "usenixsecurity", "atc")
YEARS = tuple(range(2016, 2026))
PRE, POST, TRANSITION = tuple(range(2016, 2023)), (2024, 2025), 2023
ENDPOINTS = ("ing_func_1k", "ing_interp_core_1k", "addnot_1k")
SEED, PRIMARY_DRAWS, SUPP_DRAWS = 20261021, 5000, 2000
PAUSE, TRIES, SEGMENT_MIN = 1.0, 3, 85


def sha(b):
    return hashlib.sha256(b).hexdigest()


def committed(path):
    rel = os.path.relpath(path, ROOT)
    r = subprocess.run(["git", "-C", ROOT, "status", "--porcelain", "--", rel], capture_output=True, text=True)
    t = subprocess.run(["git", "-C", ROOT, "ls-files", "--error-unmatch", rel], capture_output=True)
    return t.returncode == 0 and not r.stdout.strip()


def manifest():
    raw = open(CENSUS, "rb").read()
    assert sha(raw) == CENSUS_SHA256, "census changed since commit f08e628"
    items = []
    for line in raw.decode().splitlines():
        r = json.loads(line)
        if r["status"] != "eligible":
            continue
        slug = r["presentation"].rstrip("/").rsplit("/", 1)[1]
        items.append({"cell": r["cell"], "venue": r["cell"][:-4], "year": int(r["cell"][-4:]),
                      "source_id": f"{r['cell']}:{slug}", "presentation": r["presentation"],
                      "pdf_url": r["pdf_url"], "head_bytes": (r.get("head") or {}).get("bytes")})
    ids = [i["source_id"] for i in items]
    assert len(ids) == len(set(ids)), "duplicate source ids"
    assert len({i["pdf_url"] for i in items}) == len(items), "duplicate PDF URLs"
    os.makedirs(OUT, exist_ok=True)
    json.dump({"phase": "manifest_frozen_before_download", "census_sha256": CENSUS_SHA256,
               "rule_source": "docs/review-round3/design/CONFERENCE_PROTOCOL.md (3378c8b, ec75863)",
               "n": len(items), "items": items}, open(MANIFEST, "w"), indent=1, sort_keys=True)
    print(len(items), Counter(i["venue"] for i in items))


def pdf_path(it):
    return os.path.join(RAW, "pdfs", it["cell"], it["source_id"].split(":", 1)[1] + ".pdf")


def valid_pdf(p):
    if not os.path.exists(p):
        return False
    with open(p, "rb") as f:
        head = f.read(4)
        f.seek(max(0, os.path.getsize(p) - 2048))
        tail = f.read()
    return head == b"%PDF" and b"%%EOF" in tail


def fetch():
    assert committed(MANIFEST), "commit manifest.json before downloading"
    items = json.load(open(MANIFEST))["items"]
    os.makedirs(RAW, exist_ok=True)
    tried = Counter(r["source_id"] for r in map(json.loads, open(FETCH_LOG))) if os.path.exists(FETCH_LOG) else Counter()
    start, done = time.time(), 0
    for n, it in enumerate(items):
        dst = pdf_path(it)
        if valid_pdf(dst):
            continue
        if time.time() - start > SEGMENT_MIN * 60:
            print(f"segment budget reached after {done} new files; rerun fetch to continue", flush=True)
            return
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        for attempt in range(tried[it["source_id"]] + 1, TRIES + 1):  # same frozen URL only
            r = subprocess.run(["curl", "-sL", "-A", UA, "--max-time", "600",
                                "-w", "%{http_code} %{url_effective} %{size_download}",
                                "-o", dst + ".part", it["pdf_url"]], capture_output=True, text=True)
            code, final, size = (r.stdout.split(" ") + ["", "", ""])[:3]
            ok = valid_pdf(dst + ".part")
            with open(FETCH_LOG, "a") as f:
                f.write(json.dumps({"source_id": it["source_id"], "attempt": attempt, "url": it["pdf_url"],
                                    "http": code, "final_url": final, "bytes": size, "valid_pdf": ok,
                                    "utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())}) + "\n")
            time.sleep(PAUSE)
            if ok:
                os.replace(dst + ".part", dst)
                done += 1
                break
            time.sleep(PAUSE * 5 * attempt)
        if os.path.exists(dst + ".part"):
            os.remove(dst + ".part")
        print(n + 1, it["source_id"][:60], "ok" if valid_pdf(dst) else "FAILED", flush=True)
    print("fetch complete", flush=True)


def receipts():
    """Refuses a partial corpus unless RECEIPTS_DEVIATION holds a dated deviation note (protocol step 4)."""
    import shutil
    assert committed(MANIFEST)
    items = json.load(open(MANIFEST))["items"]
    missing = [it["source_id"] for it in items if not valid_pdf(pdf_path(it))]
    deviation = os.environ.get("RECEIPTS_DEVIATION", "").strip()
    if missing and not deviation:
        sys.exit(f"{len(missing)} selected PDFs missing or invalid (first: {missing[:5]}); retry the same URLs "
                 "with fetch, or set RECEIPTS_DEVIATION to a dated deviation note")
    shutil.copyfile(FETCH_LOG, FETCH_LOG_OUT)  # attempt log (URLs, HTTP codes, final URLs) travels with receipts
    rec = []
    for it in items:
        p = pdf_path(it)
        row = {"source_id": it["source_id"], "retrieved": valid_pdf(p)}
        if row["retrieved"]:
            b = open(p, "rb").read()
            row["pdf_sha256"], row["pdf_bytes"] = sha(b), len(b)
        rec.append(row)
    json.dump({"phase": "receipts_frozen_before_extraction", "manifest_sha256": sha(open(MANIFEST, "rb").read()),
               "fetch_log_sha256": sha(open(FETCH_LOG_OUT, "rb").read()), "missing": missing,
               "deviation": deviation or None, "items": rec}, open(RECEIPTS, "w"), indent=1, sort_keys=True)
    print(Counter(r["retrieved"] for r in rec))


def _extract(args):
    sys.path.insert(0, os.path.join(ROOT, "scripts", "review_round2", "reproduction"))
    import repro  # binds the hashed extractor snapshot, as in the main study
    cell, sid, pdf, dst = args
    if os.path.exists(dst):
        os.remove(dst)
    try:
        ok = repro.EXTRACT.one((cell, pdf, dst))
    except Exception as e:
        return sid, "extraction_error:" + type(e).__name__, None
    if not ok:
        return sid, "extraction_failed", None
    f = repro.FEATURES.paper_features(json.load(open(dst)))
    if f is None:
        return sid, "excluded_under_1500_words", None
    return sid, "admitted", {k: f[k] for k in ("words", "ing_func_1k", "ing_interp_core_1k",
                                               "op_additionally_1k", "op_notably_1k", "llm_topic")}


def extract():
    from multiprocessing import Pool
    assert committed(MANIFEST) and committed(RECEIPTS), "commit manifest.json and receipts.json first"
    rec = json.load(open(RECEIPTS))
    assert rec["manifest_sha256"] == sha(open(MANIFEST, "rb").read())
    assert committed(FETCH_LOG_OUT) and rec["fetch_log_sha256"] == sha(open(FETCH_LOG_OUT, "rb").read())
    assert not rec["missing"] or rec["deviation"], "receipts list missing PDFs without a deviation note"
    items = {i["source_id"]: i for i in json.load(open(MANIFEST))["items"]}
    assert [r["source_id"] for r in rec["items"]] == list(items), "receipts do not match the manifest"
    jobs, status = [], {}
    for r in rec["items"]:
        it = items[r["source_id"]]; p = pdf_path(it)
        if not r["retrieved"]:
            status[r["source_id"]] = {"status": "not_retrieved"}
        elif sha(open(p, "rb").read()) != r["pdf_sha256"]:
            status[r["source_id"]] = {"status": "hash_mismatch_with_receipts"}
        else:
            dst = os.path.join(RAW, "text", it["cell"], os.path.basename(p)[:-4] + ".json")
            os.makedirs(os.path.dirname(dst), exist_ok=True)
            jobs.append((it["cell"], r["source_id"], p, dst))
    with Pool(6) as pool:
        for sid, st, f in pool.imap(_extract, jobs):
            status[sid] = {"status": st, **(f or {})}
    out = []
    for sid, it in items.items():
        s = {"source_id": sid, "cell": it["cell"], "venue": it["venue"], "year": it["year"], **status[sid]}
        if s["status"] == "admitted":
            s["addnot_1k"] = s["op_additionally_1k"] + s["op_notably_1k"]
        out.append(s)
    json.dump(out, open(STATUS, "w"), indent=1, sort_keys=True)
    print(Counter((s["venue"], s["status"]) for s in out))


# ---------------------------------------------------------------- analysis (numeric rows only)
def load_rows(path=None):
    rows = [r for r in json.load(open(path or STATUS)) if r["status"] == "admitted"]
    by = defaultdict(list)
    for r in rows:
        by[(r["venue"], r["year"])].append([r[e] for e in ENDPOINTS])
    import numpy as np
    return {k: np.array(v, dtype=float) for k, v in by.items()}


def fit_lines(Y, years):
    """Y: array (len(years), V*E) of annual means. Returns (coef (2, V*E), x0) for OLS on (year - 2016)."""
    import numpy as np
    X = np.column_stack([np.ones(len(years)), np.array(years, dtype=float) - 2016])
    coef, *_ = np.linalg.lstsq(X, Y, rcond=None)
    return coef, X


def project(coef, years):
    import numpy as np
    X = np.column_stack([np.ones(len(years)), np.array(years, dtype=float) - 2016])
    return X @ coef


def annual(by, venues, years, rng=None):
    import numpy as np
    cols = []
    for v in venues:
        col = []
        for y in years:
            a = by[(v, y)]
            if rng is not None:
                a = a[rng.integers(len(a), size=len(a))]
            col.append(a.mean(axis=0))
        cols.append(np.array(col))
    return np.concatenate(cols, axis=1)  # (len(years), V*E), venue-major


def excess_point(by, venues, pre, post):
    import numpy as np
    coef, _ = fit_lines(annual(by, venues, pre), pre)
    ex = (annual(by, venues, post) - project(coef, post)).mean(axis=0)
    return ex.reshape(len(venues), len(ENDPOINTS))


def forecast_interval(by, venues, pre, post, draws=PRIMARY_DRAWS, seed=SEED):
    """Protocol primary interval: leverage-adjusted whole-year residual vectors, post-cell paper bootstrap."""
    import numpy as np
    rng = np.random.default_rng(seed)
    Ypre = annual(by, venues, pre)
    coef, X = fit_lines(Ypre, pre)
    fitted = X @ coef
    h = np.einsum("ij,jk,ik->i", X, np.linalg.inv(X.T @ X), X)
    adj = (Ypre - fitted) / np.sqrt(1 - h)[:, None]
    adj = adj - adj.mean(axis=0)
    n, V, E = len(pre), len(venues), len(ENDPOINTS)
    out = np.empty((draws, V, E))
    for d in range(draws):
        Ypost = annual(by, venues, post, rng)
        pseudo = fitted + adj[rng.integers(n, size=n)]
        c2, _ = fit_lines(pseudo, pre)
        shocks = adj[rng.integers(n, size=len(post))]
        out[d] = (Ypost - (project(c2, post) + shocks)).mean(axis=0).reshape(V, E)
    return out, {"observed_residuals": (Ypre - fitted).tolist(), "adjusted_residuals": adj.tolist(),
                 "leverage": h.tolist()}


def conditional_interval(by, venues, pre, post, draws=SUPP_DRAWS, seed=SEED):
    import numpy as np
    rng = np.random.default_rng(seed)
    out = np.empty((draws, len(venues), len(ENDPOINTS)))
    for d in range(draws):
        b = {k: by[k][rng.integers(len(by[k]), size=len(by[k]))] for k in by if k[0] in venues}
        out[d] = excess_point(b, venues, pre, post)
    return out


def summarize(point, draws):
    import numpy as np
    pooled = point.mean(axis=0); dp = draws.mean(axis=1)
    res = {"equal_venue": {}, "venues": {}}
    for j, e in enumerate(ENDPOINTS):
        lo, hi = np.quantile(dp[:, j], [0.025, 0.975])
        res["equal_venue"][e] = {"est": float(pooled[j]), "ci95": [float(lo), float(hi)]}
    for i in range(point.shape[0]):
        res["venues"][i] = {e: {"est": float(point[i, j]),
                                "ci95": [float(x) for x in np.quantile(draws[:, i, j], [0.025, 0.975])]}
                            for j, e in enumerate(ENDPOINTS)}
    return res


def verdict(eq):
    lows = [eq[e]["ci95"][0] for e in ENDPOINTS]; highs = [eq[e]["ci95"][1] for e in ENDPOINTS]
    if all(x > 0 for x in lows):
        return "full_three_endpoint_replication"
    contrary = [e for e in ENDPOINTS if eq[e]["ci95"][1] < 0]
    return "contrary:" + ",".join(contrary) if contrary else "mixed_or_inconclusive"


def analysis(by, venues=VENUES):
    import numpy as np
    def block(pre, post, draws=PRIMARY_DRAWS):
        p = excess_point(by, venues, pre, post)
        d, diag = forecast_interval(by, venues, pre, post, draws)
        s = summarize(p, d); s["venues"] = {venues[i]: v for i, v in s["venues"].items()}
        return s, diag
    prim, diag = block(PRE, POST)
    rep = {"primary_trend_excess": prim, "verdict": verdict(prim["equal_venue"]), "residual_diagnostics": diag}
    coef, _ = fit_lines(annual(by, venues, PRE), PRE)
    rep["fitted_pre_lines_2016_2022"] = {v: {e: {"intercept_2016": float(coef[0, i * len(ENDPOINTS) + j]),
                                               "slope_per_year": float(coef[1, i * len(ENDPOINTS) + j])}
                                           for j, e in enumerate(ENDPOINTS)} for i, v in enumerate(venues)}
    rep["observed_annual_means"] = {f"{v}{y}": dict(zip(ENDPOINTS, map(float, by[(v, y)].mean(axis=0))))
                                    for v in venues for y in YEARS}
    cond = summarize(excess_point(by, venues, PRE, POST), conditional_interval(by, venues, PRE, POST))
    cond["venues"] = {venues[i]: v for i, v in cond["venues"].items()}
    rep["supplemental_conditional_paper_bootstrap"] = cond
    rep["placebo_fit_2016_2019_forecast_2020_2021"], _ = block(tuple(range(2016, 2020)), (2020, 2021))
    rep["placebo_fit_2016_2020_forecast_2021_2022"], _ = block(tuple(range(2016, 2021)), (2021, 2022))
    rep["sensitivity_pre_without_2020_2021"], _ = block((2016, 2017, 2018, 2019, 2022), POST)
    # secondary raw-era contrast: mean of 2024-25 annual means minus mean of 2019-20 annual means
    def raw(b):
        return (annual(b, venues, POST).mean(axis=0) - annual(b, venues, (2019, 2020)).mean(axis=0)).reshape(len(venues), -1)
    rng = np.random.default_rng(SEED)
    rd = np.array([raw({k: by[k][rng.integers(len(by[k]), size=len(by[k]))] for k in by}) for _ in range(SUPP_DRAWS)])
    r = summarize(raw(by), rd); r["venues"] = {venues[i]: v for i, v in r["venues"].items()}
    rep["secondary_raw_2024_25_minus_2019_20"] = r
    rep["cell_n"] = {f"{v}{y}": int(len(by[(v, y)])) for v in venues for y in YEARS}
    rep["cell_means"] = {f"{v}{y}": dict(zip(ENDPOINTS, map(float, by[(v, y)].mean(axis=0)))) for v in venues for y in YEARS}
    return rep


CALIBRATION_NOTE = ("Primary forecast intervals are approximate. In synthetic null simulations "
                    "(synthetic_check.py, 200 sims, census-like cell sizes) per-endpoint coverage of zero was "
                    "about 0.88-0.91 at nominal 95% with shared calendar-year shocks (0.92-0.96 without); the "
                    "joint three-endpoint rule fired falsely in 0 of 200 null simulations.")


def analyze():
    import numpy as np
    assert committed(STATUS), "commit paper_status.json first"
    allrows = json.load(open(STATUS))
    rec = json.load(open(RECEIPTS))
    assert committed(RECEIPTS) and rec["manifest_sha256"] == sha(open(MANIFEST, "rb").read())
    assert committed(FETCH_LOG_OUT) and rec["fetch_log_sha256"] == sha(open(FETCH_LOG_OUT, "rb").read()), \
        "frozen fetch log missing or changed"
    blocking = [r["source_id"] for r in allrows if r["status"] not in ("admitted", "excluded_under_1500_words")]
    if blocking and not rec.get("deviation"):
        sys.exit(f"{len(blocking)} papers not retrieved/extracted (first: {blocking[:5]}); "
                 "no primary estimate without a dated deviation")
    by = load_rows()
    rep = {"status_sha256": sha(open(STATUS, "rb").read()), "seed": SEED, "endpoints": ENDPOINTS,
           "primary_draws": PRIMARY_DRAWS, "supplemental_draws": SUPP_DRAWS,
           "pre_years": PRE, "post_years": POST, "transition_year": TRANSITION}
    rep["calibration_note"] = CALIBRATION_NOTE
    rep["blocking_papers"] = blocking
    rep["extraction_status_by_cell"] = {f"{v}{y}": dict(Counter(r["status"] for r in allrows
                                                               if r["venue"] == v and r["year"] == y))
                                        for v in VENUES for y in YEARS}
    rep["words_by_cell"] = {}
    for v in VENUES:
        for y in YEARS:
            w = np.array([r["words"] for r in allrows if r["venue"] == v and r["year"] == y and r["status"] == "admitted"])
            rep["words_by_cell"][f"{v}{y}"] = ({"n": int(len(w)), "median": float(np.median(w)),
                                               "q25": float(np.quantile(w, .25)), "q75": float(np.quantile(w, .75))}
                                              if len(w) else {"n": 0})
    rep.update(analysis(by))
    rep["leave_one_venue_out"] = {}
    for v in VENUES:
        keep = tuple(x for x in VENUES if x != v)
        d, _ = forecast_interval(by, keep, PRE, POST)
        s = summarize(excess_point(by, keep, PRE, POST), d)
        rep["leave_one_venue_out"]["without_" + v] = s["equal_venue"]
    rows = [r for r in json.load(open(STATUS)) if r["status"] == "admitted" and r["llm_topic"] == 0]
    import numpy as np
    by0 = defaultdict(list)
    for r in rows:
        by0[(r["venue"], r["year"])].append([r[e] for e in ENDPOINTS])
    by0 = {k: np.array(v, dtype=float) for k, v in by0.items()}
    d, _ = forecast_interval(by0, VENUES, PRE, POST)
    rep["sensitivity_llm_topic_0"] = {"equal_venue": summarize(excess_point(by0, VENUES, PRE, POST), d)["equal_venue"],
                                      "cell_n": {f"{v}{y}": int(len(by0.get((v, y), []))) for v in VENUES for y in YEARS}}
    json.dump(rep, open(os.path.join(OUT, "results.json"), "w"), indent=1, sort_keys=True)
    print(json.dumps({"verdict": rep["verdict"], "primary": rep["primary_trend_excess"]["equal_venue"]}, indent=1))


def status():
    items = json.load(open(MANIFEST))["items"] if os.path.exists(MANIFEST) else []
    got = Counter(it["venue"] for it in items if valid_pdf(pdf_path(it)))
    print("manifest committed:", os.path.exists(MANIFEST) and committed(MANIFEST), "items", len(items))
    print("receipts committed:", os.path.exists(RECEIPTS) and committed(RECEIPTS))
    for v in VENUES:
        print(v, "selected", sum(it["venue"] == v for it in items), "pdf_ok", got[v])


if __name__ == "__main__":
    {"manifest": manifest, "fetch": fetch, "receipts": receipts, "extract": extract,
     "analyze": analyze, "status": status}[sys.argv[1]]()
