# Round 4 protocol: ACL Anthology census, author panel and parser check

Status: FROZEN 2026-10-22 (after pre-freeze review), written while PDFs download and before any text is extracted or any
outcome from these PDFs is seen. Analysis code frozen with it: scripts/review_round4/acl/{acl_run.py,parse_check.py}.
Owner: a reviewer (task #18). Goal: the evidence base for an ACL ARR long-paper submission.

## Why this round

The paper's language-venue evidence rests on random samples of 80–200 ACL papers per year,
a 158-paper EMNLP check and an 11-author ACL panel. A reviewer at ACL will ask three things:
does it hold in the whole *ACL literature rather than a sample; is it a change in how the
same people write, or a change in who publishes; and do the regex counts measure the
construct equally well before and after 2023. This round answers each with a frozen test.

## Frame (frozen before fetch, commit aa00a83)

- `results/review_round4/acl/catalog.json`, built by `scripts/review_round4/acl/catalog.py`
  from ACL Anthology XML at commit `2dd9f3c21ed7281fad3e5f57b2ac5cdaf18d7ca0`.
- Every paper with a PDF in the main-conference volumes of ACL (2016–2026), EMNLP
  (2016–2025) and NAACL (2016, 2018, 2019, 2021, 2022, 2024, 2025): long + short, or
  "main" where the Anthology does not split them. Findings, workshops, demos, SRW,
  industry, tutorials and journal presentations are out of frame. Front matter is excluded.
- 21,368 papers. No sampling and no replacement.
- Author keys: `authors.json` (`scripts/review_round4/acl/authors.py`), metadata only,
  committed before extraction. Rule: explicit Anthology id; else a unique match against
  the name variants in `data/json/people.json`; else a normalized name key, which may merge
  different people. `orcid_keys` lists keys of registered people with an ORCID.

Scope limit, stated before outcomes: Findings volumes began in 2020 and absorb a growing share
of accepted papers, so the main-conference population itself changes over the period.

## Fetch, receipts, extraction

- Sequential fetch of each catalog URL (`https://aclanthology.org/<id>.pdf`), ~1 request/s,
  up to 3 attempts at the same URL, every attempt logged; PDFs outside git.
- `receipts.json` (per-file SHA-256, size; missing files with a reason) is committed before
  extraction; extraction refuses missing or changed bytes. No replacement papers.
- Text extraction and features use the unchanged hashed extractor snapshot and
  `features.paper_features` via `scripts/review_round2/reproduction/repro.py`, including the
  1,500-body-word gate and the policy-section filter. `paper_rows.json` stores numeric
  features only (all features returned by `paper_features`, plus the existing `llm_topic` flag).
- Overlap with the original 9,472-paper corpus: by abstract 5-gram containment ≥ 0.5 (as in
  round 3); used only for one sensitivity run.

## Endpoints

The three frozen round-3 endpoints, rates per 1,000 extracted body words:
`ing_func_1k`, `ing_interp_core_1k`, `addnot_1k` (= `op_additionally_1k + op_notably_1k`).

## H1. Census trend excess (primary)

The lane A algorithm of `docs/review-round3/design/CONFERENCE_PROTOCOL.md`, applied unchanged
to the two annual series **ACL and EMNLP**: equal-weight annual means, a per-venue OLS line on
2016–2022, 2023 a transition year, `D[v,e]` = mean 2024–25 excess over the line, `D[e]` =
mean over the two venues. Primary interval: the same 5,000-draw leverage-adjusted
year-residual forecast bootstrap with seed `20261021` (seven joint pre-year residual vectors).
NAACL has five pre-years and no 2017/2020/2023 edition; it is reported separately with the
same algorithm on its own years and is not part of `D[e]`.

Decision: replication if all three primary lower bounds are above zero; contrary for an
endpoint whose upper bound is below zero; otherwise mixed. Secondary, reported regardless:
the paper-bootstrap conditional interval, raw 2024–25 minus 2019–20 contrast, pseudo-2020 and
pseudo-2021 placebos, `llm_topic == 0` papers only, long papers only, excluding papers that
overlap the original corpus, a pre-line fitted on 2016–2021 only (ACL 2022 was the first ACL
fully on ACL Rolling Review, so the review-system change sits inside the default baseline),
and the NAACL series.

## H2. Same first author, before and after (the composition question)

Paper `p` belongs to its first-listed author key. For an author `a` with admitted first-author
papers in both windows, `Δ_a[e]` = mean over their papers in the later window minus mean in
the earlier window, each author weighted equally.

- **Primary: real panel**, earlier 2020–2022, later 2024–2026. Estimand `mean_a Δ_a[e]`, the
  average within-author change among repeat first authors. Interval: 5,000 author-bootstrap
  draws, seed `20261022`, percentile 95%. Decision as in H1 (all three lower bounds above zero
  = the pattern appears within repeat authors, so it is not only a change in who publishes).
  This alone does not separate an era effect from career-stage drift or the pre-existing trend.
- **Placebo-adjusted contrast (secondary, descriptive):** placebo panel earlier 2016–2018,
  later 2020–2022 (the same four-year step). `DiD[e]` = real mean minus placebo mean. The two
  panels hold mostly different authors, so this needs a parallel-trends assumption and is not
  called identification. Bootstrap resamples the **union** of author keys once per draw and
  recomputes both panel means from that resample, which keeps the dependence of authors who
  are in both panels.
- **Within versus all papers (descriptive):** the all-paper change between the same two
  windows (ACL+EMNLP+NAACL, equal-author weights replaced by paper weights), reported beside
  the within-author change so a reader can see how much of the total is carried by repeat
  authors.
- Sensitivities for the primary: (i) ORCID-registered keys only; (ii) drop keys with more than
  12 first-author papers in the frame (likely merged people); (iii) only papers with
  `llm_topic == 0`; (iv) last-author panel (the senior author's papers, usually written by
  different students), reported as a contrast, not a replication test.

Frame counts known from metadata before outcomes: real panel 766 first authors (2,245 papers
in-frame), placebo 558 (1,799), 80 keys in all three windows; admitted counts after the length
gate will be smaller.

## H3. Does the regex measure the same thing in both eras?

Parser: spaCy 3.8 `en_core_web_lg` (version and model hash recorded), not a human gold
standard.

- For every census paper, re-split admitted body text into the same sentences
  (`features.sentences`) and locate every candidate counted by `features.ing_riders`, by
  re-applying its exact pattern, position rule and word-list precedence (interpretive lists
  first, then functional). `ing_riders` returns hit tokens only for interpretive matches, so the
  branches are enumerated here; a check on 300 original-corpus papers reproduces its core and
  functional counts exactly. Candidates whose token cannot be aligned to a parser token stay
  in the denominator as unconfirmed, and their count is reported.
- A candidate is **parse-confirmed** if the matched `-ing` token is tagged `VBG`, its
  dependency label is `advcl`, `acl`, `xcomp` or `conj`, and its syntactic head precedes it in
  the sentence (a non-finite clause attached to earlier material, not a gerund subject or list
  noun). Strict variant for sensitivity: `advcl` only.
- Report (a) the share of regex hits that are parse-confirmed, for functional and core
  endpoints, by era (2019–20 versus 2024–25, ACL+EMNLP), with 90% and 95% paper-bootstrap
  intervals (seed `20261024`) for the era difference; (b) H1 recomputed with parse-confirmed
  counts per 1,000 words for the **two `-ing` endpoints only**; openers are unparsed and keep
  their H1 result.
- Interpretation rule, fixed now: if, for both `-ing` endpoints, the 90% interval of the era
  difference in confirmed share lies entirely within ±10 percentage points (an equivalence
  test) and parse-confirmed H1 keeps both lower bounds above zero, we write that "the spaCy
  parse corroborates that the regex trend is not driven by a change in regex precision". The
  parser is not human gold, so we do not write that the trend is "not an artifact". Anything
  else is reported as a measurement caveat.

Openers are anchored, sentence-initial string matches and are not parsed.

## H4. Pre-declared directional test of the 2026 opener retreat

Round 3 found, after seeing outcomes, that arXiv opener rates fell in 2026. The ACL 2026
census was written before that observation was made and is a fresh test.

- Prediction: mean `addnot_1k` in ACL 2026 is **lower** than in ACL 2025.
- Test: difference of annual means, 5,000-draw paper bootstrap within each year (seed
  `20261023`); confirmed if the 95% upper bound is below zero. Reported with the distribution
  of the six pre-period ACL year-to-year changes (2016→17 … 2021→22) as a reference for normal
  year shocks; the bootstrap covers sampling noise only.
- Timing: ACL 2026 papers went through ARR cycles that closed around February 2026, so this
  measures late-2025 writing, not the July–September 2026 window where arXiv `-ing` fell.
- Power: the minimum detectable difference (80% power, one-sided α = 0.025, from the observed
  2025 and 2026 paper SDs and counts) is reported beside the estimate, so a null is not read
  as evidence of no retreat.
- The two `-ing` endpoints get the same difference reported descriptively, with no prediction:
  the arXiv `-ing` drop sat mostly in July–September 2026, after ACL 2026 was written.

## Exploratory (labelled as such)

All features from `paper_features`, each with the H1 point estimate and a
Benjamini–Hochberg-adjusted paper-bootstrap p-value; between-paper dispersion of the three
endpoints by year. These may suggest hypotheses but do not enter claims of replication.

## Reporting and limits

Every number in the paper must be reproducible from committed numeric rows by one command.
A second agent recomputes H1–H4 from `paper_rows.json` before the results enter the paper.
These are publication-era associations of surface patterns in one research community; they
do not identify AI use in any paper. No public site or blog update is authorized here.

## Deviation log

- 2026-10-22 21:30Z, before freeze: review by a reviewer and a reviewer. H2 primary changed to the within-author real-panel change; placebo
  subtraction became a secondary contrast with union-of-authors bootstrap; H3 enumerates both
  regex branches, keeps unaligned candidates in the denominator, uses a ±10-point equivalence
  rule on the 90% interval and applies parse-confirmed H1 to the two `-ing` endpoints only;
  added the 2016–2021 pre-line sensitivity (ARR) and the H4 timing and power statements.
- 2026-10-23 03:18Z, after extraction and overlap, before any analysis output was viewed (a reviewer):
  the without-overlap H1 sensitivity is also reported with the 460 papers lacking a usable abstract
  dropped (they cannot be tested for overlap). Computed by `scripts/review_round4/acl/supplementary.py`
  with the same `h1_block`; both versions are reported.
- 2026-10-24, **after outcomes; documentation only, no estimate changes** (round-5 reproduction, a reviewer;
  correction requested by a reviewer):
  (a) The last-author contrast, as implemented in `acl_run.py` (`last` uses only bylines with at least two
  authors), excludes single-author papers. The frozen 913 authors reflect that; including single-author papers
  would give 928. This entry documents the existing implementation and was not chosen after seeing outcomes. The paper's
  sensitivity text now states the exclusion.
  (b) The 460 papers without a usable abstract were stored only as a count. Their IDs were recovered on
  2026-10-24 by re-applying the identical rule (fewer than 10 word 5-grams in the extracted abstract;
  `supplementary.py`) to the same extracted text, and are frozen in `results/review_round4/acl/abstractless_ids.json`
  with per-file text SHA-256. Re-running the supplementary sensitivity from numeric rows plus that list reproduces
  `supplementary.json` exactly (0 mismatches).
