#!/usr/bin/env python3
"""Recompute H1, H2 and H4 from data/ and compare with data/results_frozen.json. Needs numpy.
Usage: python3 reproduce.py"""
import importlib.util, json, math, os, sys
HERE = os.path.dirname(os.path.abspath(__file__))
os.environ.setdefault("ACL_RAW", os.path.join(HERE, "_unused_raw"))
spec = importlib.util.spec_from_file_location("acl_run", os.path.join(HERE, "code", "acl_run.py"))
m = importlib.util.module_from_spec(spec)
m.__dict__["__file__"] = os.path.join(HERE, "code", "acl_run.py")
spec.loader.exec_module(m)
m.ROOT = HERE  # so the lane-A import resolves inside the bundle
rows = json.load(open(os.path.join(HERE, "data", "paper_rows.json")))
rows = rows["rows"] if isinstance(rows, dict) else rows
rows = [r for r in rows if r.get("status", "admitted") == "admitted"] if rows and "status" in rows[0] else rows
au = json.load(open(os.path.join(HERE, "data", "authors_anon.json")))
ov = set(json.load(open(os.path.join(HERE, "data", "overlap.json")))["overlapping"])
A = m._lane_a()
got = {"H1": m.h1(A, rows, ov), "H2": m.h2(rows, au["byline"], set(au["orcid_keys"])), "H4": m.h4(rows)}
noabs = set(json.load(open(os.path.join(HERE, "data", "abstractless_ids.json")))["ids"])
s_by = m.cells(rows, lambda r: r["id"] not in ov and r["id"] not in noabs)
got["SUPP"], _ = m.h1_block(A, s_by, ("acl", "emnlp"), m.PRE, m.POST)
ref = json.load(open(os.path.join(HERE, "data", "results_frozen.json")))
bad = []
def cmp(a, b, p):
    if isinstance(b, dict):
        if not isinstance(a, dict): bad.append((p, type(a).__name__, "dict")); return
        for k in sorted(set(a) | set(b)):
            if k not in a or k not in b: bad.append((p + "/" + k, "present" if k in a else "MISSING", "present" if k in b else "MISSING"))
            else: cmp(a[k], b[k], p + "/" + k)
    elif isinstance(b, list):
        if not isinstance(a, list) or len(a) != len(b): bad.append((p, len(a) if isinstance(a, list) else type(a).__name__, len(b))); return
        for i, (x, y) in enumerate(zip(a, b)): cmp(x, y, p + f"[{i}]")
    elif isinstance(b, bool) or isinstance(a, bool) or isinstance(b, str) or b is None:
        if a != b: bad.append((p, a, b))
    elif isinstance(b, (int, float)):
        if not (isinstance(a, (int, float)) and math.isclose(a, b, rel_tol=1e-9, abs_tol=1e-12)): bad.append((p, a, b))
    elif a != b:
        bad.append((p, a, b))
supp_ref = json.load(open(os.path.join(HERE, "data", "supplementary_frozen.json")))["sensitivity_without_overlap_and_without_abstractless"]
for k in got: cmp(got[k], supp_ref if k == "SUPP" else ref[k], k)
print("mismatches:", len(bad)); [print(*x) for x in bad[:20]]
sys.exit(1 if bad else 0)
